package com.star.agile.assignment.Springboootdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringboootDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
